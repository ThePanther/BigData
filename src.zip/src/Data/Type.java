package Data;


public enum Type {
    LOGIN,LOGOUT,MESSAGE,REGISTRATION,USERSEARCH,RESPONSE
}
