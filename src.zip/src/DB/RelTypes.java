package DB;

import org.neo4j.graphdb.RelationshipType;

public enum RelTypes implements RelationshipType {
    KNOWS,SEND
}
